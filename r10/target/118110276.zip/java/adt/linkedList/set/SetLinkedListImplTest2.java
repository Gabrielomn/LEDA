package adt.linkedList.set;

import static org.junit.jupiter.api.Assertions.*;

class SetLinkedListImplTest2 {

}