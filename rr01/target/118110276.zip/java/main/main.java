package main;

import solucao.forma.Circulo;
import solucao.forma.Forma;

public class main {

    public static void main(String[] args){

        Forma f1 = new Circulo(5);
        System.out.println(f1.area());


    }
}
